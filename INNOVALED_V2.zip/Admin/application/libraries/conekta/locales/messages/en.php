<?php

return array(
    'error' => array(
        'resource' => array(
            'id'           => 'Could not get the id of RESOURCE instance.',
            'id_purchaser' => 'There was an error. Please contact system administrator.',
        ),
        'requestor' => array(
            'connection'           => 'Could not connect to BASE.',
            'connection_purchaser' => 'Could not connect to payment system.',
        ),
    ),
);
