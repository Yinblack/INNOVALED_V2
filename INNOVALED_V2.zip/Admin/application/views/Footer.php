                        
                    </div>
                    <!-- END PAGE CONTAINER -->
                    
                </div>
                <!-- END APP CONTENT -->
                                
            </div>
            <!-- END APP CONTAINER -->            
            
            <!-- APP OVERLAY -->
            <div class="app-overlay"></div>
            <!-- END APP OVERLAY -->
        </div>        
        <!-- END APP WRAPPER -->                
        
        <!-- IMPORTANT SCRIPTS -->
        <script type="text/javascript" src="assets/js/vendor/jquery/jquery.min.js"></script>
        <script type="text/javascript" src="assets/js/vendor/jquery/jquery-ui.min.js"></script>
        <script type="text/javascript" src="assets/js/vendor/bootstrap/bootstrap.min.js"></script>
        <script type="text/javascript" src="assets/js/vendor/moment/moment.min.js"></script>
        <script type="text/javascript" src="assets/js/vendor/customscrollbar/jquery.mCustomScrollbar.min.js"></script>
        <!-- END IMPORTANT SCRIPTS -->
        <!-- APP SCRIPTS -->
        <script type="text/javascript" src="assets/js/app.js"></script>
        <script type="text/javascript" src="assets/js/app_plugins.js"></script>
        <script type="text/javascript" src="assets/js/app_demo.js"></script>
        <script type="text/javascript" src="assets/js/dev.js"></script>
        <?=$js?>
        <!-- END APP SCRIPTS -->
        
        <!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = 'lGpcGkMLuU';var d=document;var w=window;function l(){
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();</script>
<!-- {/literal} END JIVOSITE CODE -->
    </body>
</html>