    </div>
  </div>
  <div id="modal-youtube" data-izimodal-autoopen data-izimodal-transitionin="fadeInDown"></div>
</body>

<!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = 'lGpcGkMLuU';var d=document;var w=window;function l(){
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();</script>
<!-- {/literal} END JIVOSITE CODE -->


<!-- Latest compiled and minified JavaScript -->
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<script src='assets/js/web/parallax.min.js'></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.16.0/jquery.validate.min.js"></script>
<script src="https://unpkg.com/fg-loadjs@1.0.0"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/scrollReveal.js/3.3.6/scrollreveal.min.js"></script>
<script type="text/javascript" src="assets/js/site/jquery.onepage-scroll.js"></script>
<script src='assets/js/web/slick.js'></script>
<script type="text/javascript" src="assets/js/site/tabs.js"></script>
<script type="text/javascript" src="assets/js/site/map.js"></script>

<?php if(isset($js)) echo $js; ?>
<script src='assets/js/site/dev.js'></script>
</html>